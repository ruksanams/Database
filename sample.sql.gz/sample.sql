-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2020 at 01:53 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sample`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `EMPLOYEE_ID` int(10) NOT NULL,
  `FIRST_NAME` varchar(15) NOT NULL,
  `LAST_NAME` varchar(10) NOT NULL,
  `SALARY` int(7) NOT NULL,
  `JOINING_DATE` date NOT NULL,
  `DEPARTMENT` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EMPLOYEE_ID`, `FIRST_NAME`, `LAST_NAME`, `SALARY`, `JOINING_DATE`, `DEPARTMENT`) VALUES
(1, 'Ruksana', 'M', 25000, '2020-01-01', 'HR'),
(2, 'Sajini', 'John', 30000, '2019-12-18', 'IT'),
(3, 'Maria', 'Joseph', 30000, '2020-01-02', 'IT'),
(3, 'Kukku', 'Mol', 25000, '2019-11-13', 'Marketing'),
(4, 'Jismi', 'Jose', 20000, '2019-10-08', 'Developer'),
(5, 'Aneesh', 'K', 30000, '2019-10-16', 'IT'),
(6, 'Subimol', 'Chacko', 18000, '2020-01-03', 'Marketing'),
(7, 'Irfana', 'K', 18000, '2020-01-15', 'Developer'),
(8, 'Salvishah', 's', 20000, '2019-09-10', 'Tester'),
(9, 'Anvar', 'Shah', 30000, '2019-03-20', 'HR'),
(10, 'Meera', 'K', 30000, '2019-08-16', 'Tester'),
(11, 'Jeena', 'Sajeev', 35000, '2020-01-01', 'Marketing'),
(12, 'Vimal', 'Kumar', 25000, '2019-11-12', 'IT'),
(13, 'Kamal', 'Raj', 30000, '2019-03-22', 'Tester'),
(14, 'Jasna', 'Shajahan', 25000, '2020-01-01', 'HR'),
(15, 'Arun', 'Raj', 28000, '2019-09-18', 'Developer');

-- --------------------------------------------------------

--
-- Table structure for table `incentive`
--

CREATE TABLE `incentive` (
  `EMPLOYEE_ID` int(10) NOT NULL,
  `INCENTIVE_DATE` date NOT NULL,
  `INCENTIVE_AMOUNT` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `incentive`
--

INSERT INTO `incentive` (`EMPLOYEE_ID`, `INCENTIVE_DATE`, `INCENTIVE_AMOUNT`) VALUES
(1, '2019-12-04', 500),
(3, '2019-12-04', 2000),
(15, '2019-11-13', 1000),
(13, '2020-01-01', 750),
(8, '2019-12-25', 1500),
(7, '2019-12-03', 350);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
